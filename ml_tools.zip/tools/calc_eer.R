###############
## created by Shunichi Ishihara, Tuesday, 11 October 2011
##
## get.closest.value is a function which returns the closest value
## to the specified value from the list
## get.closest value takes a list of numerical values (list)
## and a numerical value (value)

get.closest.value<-function(list, value) {
   index<-which(abs(list - value) == min(abs(list - value)))
   return(index)

}

###############

###############
## created by Shunichi Ishihara, Tuesday, 11 October 2011
##
## calc.eer is a function which take a list of SS LRs (SS.lrs.list)
## and that of DS LRs (DS.lrs.list) and
## returns the esimated Equal Error Rate (EER)
##
## get.closest.value is used in the calc.eer.

calc.eer<-function(SS.lrs.list, DS.lrs.list,filename) {
 sorted.SS.lrs<-sort(SS.lrs.list)
 sorted.DS.lrs<-sort(DS.lrs.list,decreasing=FALSE)
 length.SS.lrs<-length(sorted.SS.lrs)
 length.DS.lrs<-length(sorted.DS.lrs)
 ss.interval<-1 / (length.SS.lrs - 1)
 ds.interval<-1 / (length.DS.lrs - 1)

 density.list.ss<-NULL
 density.list.ds<-NULL 
 
 for (i in 0:(length.SS.lrs - 1)) {
   density.list.ss<-c(density.list.ss, (i * ss.interval))

 }

 for (i in 0:(length.DS.lrs - 1)) {
   density.list.ds<-c(density.list.ds, (i * ds.interval))

 }

 ss.lrs.density<-cbind(sorted.SS.lrs, sort(density.list.ss,decreasing=FALSE))
 ds.lrs.density<-cbind(sorted.DS.lrs, sort(density.list.ds,decreasing=TRUE))

 ## print(ds.lrs.density[,1])
 ## print(ds.lrs.density)

 difference.list<-NULL
 for (i in 1:length(ds.lrs.density[,1])) {
   ds.lr.value<-ds.lrs.density[i,1]
   ds.density.value<-ds.lrs.density[i,2]
   
   closet.ss.lr.value.index<-get.closest.value(ss.lrs.density[,1], ds.lr.value)
   # print(ds.lr.value)
   ss.closet.density.value<-ss.lrs.density[closet.ss.lr.value.index,2]

   density.difference<-abs(ds.density.value - ss.closet.density.value)
   difference.list<-c(difference.list,density.difference)
   
 }

 final.index<-which(difference.list == min(difference.list))
 target.ds.lr<-unname(ds.lrs.density[final.index,1])
 target.ss.lr.index<-get.closest.value(ss.lrs.density[,1], target.ds.lr)
 target.ss.lr<-ss.lrs.density[target.ss.lr.index,1]

 target.ds.density<-unname(ds.lrs.density[final.index,2])
 target.ss.density<-ss.lrs.density[target.ss.lr.index,2]

 estimated.eer<-((target.ds.density + target.ss.density) / 2)

 write.table(estimated.eer,file=filename, sep=" ", quote=FALSE, row.names = FALSE, col.names = FALSE)
 
 return(unname(estimated.eer))

}

calculateEqualError <- function(sa.score.file,da.score.file,write.filename) {
    
    userScores.one<-read.table(sa.score.file,header=FALSE)
    impostorScores.one<-read.table(da.score.file,header=FALSE)
    userScores<-userScores.one[,2]
    impostorScores<-c(impostorScores.one[,3],impostorScores.one[,4])

    predictions <- c( userScores, impostorScores );
    labels <- c( rep( 0, length( userScores ) ),
                rep( 1, length( impostorScores ) ) );
  
    pred <- prediction( predictions, labels );

    missrates <- pred@fn[[1]] / pred@n.pos[[1]];
    farates <- pred@fp[[1]] / pred@n.neg[[1]];

    # Find the point on the ROC with miss slightly >= fa, and the point
    # next to it with miss slightly < fa.
  
    dists <- missrates - farates;
    idx1 <- which( dists == min( dists[ dists >= 0 ] ) );
    idx2 <- which( dists == max( dists[ dists < 0 ] ) );
    stopifnot( length( idx1 ) == 1 );
    stopifnot( length( idx2 ) == 1 );
    stopifnot( abs( idx1 - idx2 ) == 1 );

    # Extract the two points as (x) and (y), and find the point on the
    # line between x and y where the first and second elements of the
    # vector are equal.  Specifically, the line through x and y is:
    #   x + a*(y-x) for all a, and we want a such that
    #   x[1] + a*(y[1]-x[1]) = x[2] + a*(y[2]-x[2]) so
    #   a = (x[1] - x[2]) / (y[2]-x[2]-y[1]+x[1])
  
    x <- c( missrates[idx1], farates[idx1] );
    y <- c( missrates[idx2], farates[idx2] );
    a <- ( x[1] - x[2] ) / ( y[2] - x[2] - y[1] + x[1] );
    discrimination.accuracy <- x[1] + a * ( y[1] - x[1] );
    eer<-(1 - discrimination.accuracy)
    write.table(eer,file=write.filename, sep=" ", quote=FALSE, row.names = FALSE, col.names = FALSE)

  return( eer );
}

###############



