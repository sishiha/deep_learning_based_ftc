cross.validation.calibrate<-function(TSS1,
                    TDS1,
                    ssfilename,
                    dsfilename,
                    filename
                    ) {

    file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    sapply(file.sources1,source,.GlobalEnv)
    sapply(file.sources2,source,.GlobalEnv)
    sapply(file.sources3,source,.GlobalEnv)

### test data ###
    datatss1 <- read.table(TSS1,header=FALSE)
    datatds1 <- read.table(TDS1,header=FALSE)

    tss1 <- as.vector(datatss1[,2])
    logetss <- rbind(log(10^tss1))
    
    tds11 <- as.vector(datatds1[,3])
    tds12 <- as.vector(datatds1[,4])

    tds1 = c(tds11, tds12)
    logetds <- rbind(log(10^tds1))

### calculate logistic-regression weights in cross-validation manner
############### 
    length.logetss<-length(logetss)
    length.logetds<-length(logetds)

############### same origin 
    list.cross.validated.target<-NULL

    pb <- txtProgressBar(min = 1, max = length.logetss, style = 3)

    cat("...... Calibrating SS scores")
    cat(" ......\n")
    
    for (i in 1:length.logetss) {
        specific.logetss.lr<-logetss[1,i]
        everything.else.logetss.lrs<-t(as.matrix(logetss[1,-i]))

        w <- train.llr.fusion(everything.else.logetss.lrs,logetds)
        targetf <- lin.fusion(w, as.matrix(specific.logetss.lr))
        list.cross.validated.target<-c(list.cross.validated.target,targetf)
        setTxtProgressBar(pb, i)        
    }

    close(pb)
    
############### same origin end
############### different origin 
    list.cross.validated.non.target<-NULL
    
    pb <- txtProgressBar(min = 1, max = length.logetds, style = 3)

    cat("...... Calibrating DS scores")
    cat(" ......\n")
    
    for (i in 1:length.logetds) {
        specific.logetds.lr<-logetds[1,i]
        everything.else.logetds.lrs<-t(as.matrix(logetds[1,-i]))

        w <- train.llr.fusion(logetss,everything.else.logetds.lrs)
        nontargetf <- lin.fusion(w, as.matrix(specific.logetds.lr))
        list.cross.validated.non.target<-c(list.cross.validated.non.target,nontargetf)
        setTxtProgressBar(pb, i)        
    }

    close(pb)
    
############### different origin end
    log10targetf <- as.vector(log10(exp(list.cross.validated.target)))
    log10nontargetf <- as.vector(log10(exp(list.cross.validated.non.target)))
    
### calculate logistic-regression weights in cross-validation manner end
    write(log10targetf, file=ssfilename, ncolumns = 1)
    write(log10nontargetf, file=dsfilename, ncolumns = 1)

    non.calib.cllr.value <- cllr(logetss,logetds)
    non.calib.cllr.min.value <- cllr.min(logetss,logetds)
    non.calib.cllr.cal.value <- cllr.cal(logetss,logetds)
    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
                                       non.calib.cllr.min.value,
                                       non.calib.cllr.cal.value
                                       )

    calib.cllr.value <- cllr(list.cross.validated.target,list.cross.validated.non.target)
    calib.cllr.min.value <- cllr.min(list.cross.validated.target,list.cross.validated.non.target)
    calib.cllr.cal.value <- cllr.cal(list.cross.validated.target,list.cross.validated.non.target)
    calib.cllr.min.cal.values <- c(calib.cllr.value, calib.cllr.min.value, calib.cllr.cal.value)

    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
    )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(calib.cllr.min.cal.values)
    
    rm(list=ls(all=TRUE))

}

calibrate<-function(TSS1,
                    TDS1,
                    DSS1,
                    DDS1,
                    ssfilename,
                    dsfilename,
                    filename
                    ) {

    file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    sapply(file.sources1,source,.GlobalEnv)
    sapply(file.sources2,source,.GlobalEnv)
    sapply(file.sources3,source,.GlobalEnv)

### test data ###
    datatss1 <- read.table(TSS1,header=FALSE)
    datatds1 <- read.table(TDS1,header=FALSE)
    
    tss1 <- as.vector(datatss1[,2])
    logetss <- rbind(log(10^tss1))

    tds11 <- as.vector(datatds1[,3])
    tds12 <- as.vector(datatds1[,4])

    tds1 = c(tds11, tds12)
    logetds <- rbind(log(10^tds1))

### development data ###
    datadss1 <- read.table(DSS1,header=FALSE)
    datadds1 <- read.table(DDS1,header=FALSE)

    dss1 <- as.vector(datadss1[,2])
    logedss <- rbind(log(10^dss1))

    dds11 <- as.vector(datadds1[,3])
    dds12 <- as.vector(datadds1[,4])

    dds1 = c(dds11, dds12)
    logedds <- rbind(log(10^dds1))

### calculate logistic-regression weights
    w <- train.llr.fusion(logedss,logedds)

### convert scores to LRs
    targetf <- lin.fusion(w, logetss)
    nontargetf <- lin.fusion(w, logetds)

    log10targetf <- as.vector(log10(exp(targetf)))
    log10nontargetf <- as.vector(log10(exp(nontargetf)))

    write(log10targetf, file=ssfilename, ncolumns = 1)
    write(log10nontargetf, file=dsfilename, ncolumns = 1)

    non.calib.cllr.value <- cllr(logetss,logetds)
    # print(non.calib.cllr.value)
    # non.calib.cllr.min.value <- cllr.min(logetss,logetds)
    # print(non.calib.cllr.min.value)
    # non.calib.cllr.cal.value <- cllr.cal(logetss,logetds)
    # non.calib.cllr.cal.value <- non.calib.cllr.value - non.calib.cllr.min.value
    # non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
    #                                   non.calib.cllr.min.value,
    #                                   non.calib.cllr.cal.value
    #                                   )
    # print(non.calib.cllr.min.cal.values)

    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value)

    calib.cllr.value <- cllr(targetf,nontargetf)
    # calib.cllr.min.value <- cllr.min(targetf,nontargetf)
    # calib.cllr.cal.value <- cllr.cal(targetf,nontargetf)
    # calib.cllr.min.cal.values <- c(calib.cllr.value, calib.cllr.min.value, calib.cllr.cal.value)
    calib.cllr.min.cal.values <- c(calib.cllr.value)

    # title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal"),
    #                                        c("before_calib", non.calib.cllr.min.cal.values),
    #                                        c("after_calib", calib.cllr.min.cal.values))
    #                              )
    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
                                  )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(rbind(non.calib.cllr.min.cal.values, calib.cllr.min.cal.values))

    rm(list=ls(all=TRUE))

}

calibrate.roc.eer<-function(TSS1,
                    TDS1,
                    DSS1,
                    DDS1,
                    ssfilename,
                    dsfilename,
                    filename) {

    # file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    # file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    # file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    # sapply(file.sources1,source,.GlobalEnv)
    # sapply(file.sources2,source,.GlobalEnv)
    # sapply(file.sources3,source,.GlobalEnv)

### test data ###
    datatss1 <- read.table(TSS1,header=FALSE)
    datatds1 <- read.table(TDS1,header=FALSE)
    
    tss1 <- as.vector(datatss1[,2])
    # logetss <- rbind(log(10^tss1))
    logetss <- rbind(tss1*log(10))

    tds11 <- as.vector(datatds1[,3])
    tds12 <- as.vector(datatds1[,4])

    tds1 = c(tds11, tds12)
    # logetds <- rbind(log(10^tds1))
    logetds <- rbind(tds1*log(10))

### development data ###
    datadss1 <- read.table(DSS1,header=FALSE)
    datadds1 <- read.table(DDS1,header=FALSE)

    dss1 <- as.vector(datadss1[,2])
    # logedss <- rbind(log(10^dss1))
    logedss <- rbind(dss1*log(10))

    dds11 <- as.vector(datadds1[,3])
    dds12 <- as.vector(datadds1[,4])

    dds1 = c(dds11, dds12)
    # logedds <- rbind(log(10^dds1))
    logedds <- rbind(dds1*log(10))

### calculate logistic-regression weights
    w <- train.llr.fusion(logedss,logedds)

### convert scores to LRs
    targetf <- lin.fusion(w, logetss)
    nontargetf <- lin.fusion(w, logetds)

    log10targetf <- as.vector(log10(exp(targetf)))
    # log10targetf <- as.vector(targetf/log(10))
    log10nontargetf <- as.vector(log10(exp(nontargetf)))
    # log10nontargetf <- as.vector(nontargetf/log(10))

    write(log10targetf, file=ssfilename, ncolumns = 1)
    write(log10nontargetf, file=dsfilename, ncolumns = 1)

### non calib cllr, cllrmin, cllrcal values
    da.false.values<-rep(FALSE, length(logetds))
    sa.true.values<-rep(TRUE, length(logetss))
    sa.da.scores<-c(logetss,logetds)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)
    non.calib.cllr.value<-summary.roc(roc.out)$Cllr
    non.calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    non.calib.cllr.cal.value<-non.calib.cllr.value - non.calib.cllr.min.value
    non.calib.eer.value<-summary.roc(roc.out)$eer / 100
    
    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
                                       non.calib.cllr.min.value,
                                       non.calib.cllr.cal.value,
                                       non.calib.eer.value)

### calib cllr, cllrmin, cllrcal values    
    da.false.values<-rep(FALSE, length(nontargetf))
    sa.true.values<-rep(TRUE, length(targetf))
    sa.da.scores<-c(targetf,nontargetf)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)
    calib.cllr.value<-summary.roc(roc.out)$Cllr
    calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    calib.cllr.cal.value<-calib.cllr.value - calib.cllr.min.value
    calib.eer.value<-summary.roc(roc.out)$eer / 100

    calib.cllr.min.cal.values <- c(calib.cllr.value,
                                   calib.cllr.min.value,
                                   calib.cllr.cal.value,
                                   calib.eer.value
                                   )
    
    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal", "eer"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
    )

    # title.eer.values<-(rbind(c("before/after_calib", "eer"),
    #                                        c("before_calib", non.calib.eer.value/100),
    #                                        c("after_calib", calib.eer.value/100))
    # )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    # write.table(title.eer.values,file=eerfilename, sep=" ", quote=FALSE,
    #            row.names = FALSE, col.names = FALSE)

    # print(paste("EER:", non.calib.eer.value/100, calib.eer.value/100, sep=" "))

    return(rbind(non.calib.cllr.min.cal.values, calib.cllr.min.cal.values))

    rm(list=ls(all=TRUE))

}

calibrate.roc.eer.ver2<-function(tf,
                                df,
                                lrfilename,
                                filename) {

    file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    sapply(file.sources1,source,.GlobalEnv)
    sapply(file.sources2,source,.GlobalEnv)
    sapply(file.sources3,source,.GlobalEnv)

    test.readin<-read.table(tf, header=TRUE)
    
    tss1<-test.readin[which(test.readin[,5] == 1),1]
    logetss <- rbind(tss1*log(10))

    tss1.author.pairs<-test.readin[which(test.readin[,5] == 1),2]
    
    tss1.product.pairs<-test.readin[which(test.readin[,5] == 1),3]
    tss1.fixed.product.pairs<-test.readin[which(test.readin[,5] == 1),4]
    tss1.so.do<-test.readin[which(test.readin[,5] == 1),5]

    tds1<-test.readin[which(test.readin[,5] == 0),1]
    logetds <- rbind(tds1*log(10))

    tds1.author.pairs<-test.readin[which(test.readin[,5] == 0),2]

    tds1.product.pairs<-test.readin[which(test.readin[,5] == 0),3]
    tds1.fixed.product.pairs<-test.readin[which(test.readin[,5] == 0),4]
    tds1.so.do<-test.readin[which(test.readin[,5] == 0),5]
    
    t1.author.pairs<-c(as.vector(tss1.author.pairs), as.vector(tds1.author.pairs))
    t1.product.pairs<-c(as.vector(tss1.product.pairs), as.vector(tds1.product.pairs))
    t1.fixed.product.pairs<-c(as.vector(tss1.fixed.product.pairs), as.vector(tds1.fixed.product.pairs))
    t1.so.do<-c(as.vector(tss1.so.do), as.vector(tds1.so.do))

    development.readin<-read.table(df, header=TRUE)
    dss1<-development.readin[which(development.readin[,5] == 1),1]
    logedss <- rbind(dss1*log(10))

    dds1<-development.readin[which(development.readin[,5] == 0),1]
    logedds <- rbind(dds1*log(10))

    w <- train.llr.fusion(logedss,logedds)

    targetf <- lin.fusion(w, logetss)
    nontargetf <- lin.fusion(w, logetds)

    log10targetf <- as.vector(log10(exp(targetf)))
    log10nontargetf <- as.vector(log10(exp(nontargetf)))

    log10tf<-c(as.vector(log10targetf),as.vector(log10nontargetf))

    lrs.out<-data.frame(lrs=log10tf,
                        authorpairs=t1.author.pairs,
                        productpairs = t1.product.pairs,
                        fixedproductpairs = t1.fixed.product.pairs,
                        sodo=t1.so.do)

    write.table(lrs.out, lrfilename, sep=" ", row.names=FALSE, quote=FALSE)

### non calib cllr, cllrmin, cllrcal values
    da.false.values<-rep(FALSE, length(logetds))
    sa.true.values<-rep(TRUE, length(logetss))
    sa.da.scores<-c(logetss,logetds)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)
    non.calib.cllr.value<-summary.roc(roc.out)$Cllr
    non.calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    non.calib.cllr.cal.value<-non.calib.cllr.value - non.calib.cllr.min.value
    non.calib.eer.value<-summary.roc(roc.out)$eer / 100
    
    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
                                       non.calib.cllr.min.value,
                                       non.calib.cllr.cal.value,
                                       non.calib.eer.value)

### calib cllr, cllrmin, cllrcal values    
    da.false.values<-rep(FALSE, length(nontargetf))
    sa.true.values<-rep(TRUE, length(targetf))
    sa.da.scores<-c(targetf,nontargetf)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)
    calib.cllr.value<-summary.roc(roc.out)$Cllr
    calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    calib.cllr.cal.value<-calib.cllr.value - calib.cllr.min.value
    calib.eer.value<-summary.roc(roc.out)$eer / 100

    calib.cllr.min.cal.values <- c(calib.cllr.value,
                                   calib.cllr.min.value,
                                   calib.cllr.cal.value,
                                   calib.eer.value
                                   )
    
    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal", "eer"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
    )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(rbind(non.calib.cllr.min.cal.values, calib.cllr.min.cal.values))

    rm(list=ls(all=TRUE))

}
