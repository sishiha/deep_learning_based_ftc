da.matrix<-function(vector.x) {
    initial<-(vector.x[1] - 1)
    # print(initial)

    how.many.nrows<-length(vector.x)
    no.author <- how.many.nrows/2

    how.many <- no.author -1
    DA.sus.indicies <- c()
    DA.sus.names <- c()
    DA.off.indicies <- c()
    DA.off.names <- c()
    for(i in 1: (no.author - 1)) {
        DA.sus.index.tmp <- rep(i,how.many)
        DA.off.index.tmp <- seq(from= (i+1), to= no.author)
        DA.sus.indicies <- c(DA.sus.indicies,DA.sus.index.tmp)
        DA.off.indicies <- c(DA.off.indicies,DA.off.index.tmp)
        how.many <- how.many - 1

    }

    qq<-(as.matrix(cbind(DA.sus.indicies,DA.off.indicies)) + initial)
    return(qq)
}

extract.target.so.values.from.matrix<-function(matrix.x) {
    how.many.nrows<-nrow(matrix.x)

    odd<-seq(1,how.many.nrows,2)
    even<-seq(2,by=2, len=how.many.nrows/2)

    # print(cbind(odd,even))
    # stop()

    ### extracting only same author distance values
    ### extracting only same author distance values
    sa.distance.values<-matrix.x[cbind(even,odd)]
    bad.zero<-which(sa.distance.values == 0)
    if (length(bad.zero) > 0) {
        sa.distance.values<-replace(sa.distance.values,
                                    which(sa.distance.values == 0),
                                    1/10^9)
        # sa.distance.values<-sa.distance.values[-bad.zero]
        print("Some values are zero in sa")

    }

    return(sa.distance.values)
}


extract.target.do.values.from.matrix<-function(matrix.x) {
    how.many.nrows<-nrow(matrix.x)
    no.author <- how.many.nrows/2

    how.many <- no.author -1
    DA.sus.indicies <- c()
    DA.sus.names <- c()
    DA.off.indicies <- c()
    DA.off.names <- c()
    for(i in 1: (no.author - 1)) {
        DA.sus.index.tmp <- rep(i,how.many)
        DA.off.index.tmp <- seq(from= (i+1), to= no.author)
        DA.sus.indicies <- c(DA.sus.indicies,DA.sus.index.tmp)
        DA.off.indicies <- c(DA.off.indicies,DA.off.index.tmp)
        how.many <- how.many - 1

    }

    qq<-as.matrix(cbind(DA.sus.indicies,DA.off.indicies))
    q.rows<-as.numeric(nrow(qq))
    da.distance.values<-c()

    ### extracting only different author distance values
    ### extracting only different author distance values
    v1<-matrix.x[cbind((qq*2-1)[,1],(qq*2-1)[,2])]
    v2<-matrix.x[cbind((qq*2)[,1],(qq*2)[,2])]
    da.distance.values<-c(v1,v2)

    ### process for removing zero distance values
    ### process for removing zero distance values
    bad.zero<-which(da.distance.values == 0)
    if (length(bad.zero) > 0) {
        # da.distance.values<-replace(da.distance.values,
        #                            which(da.distance.values == 0),
        #                            1/10^9)
        da.distance.values<-da.distance.values[-bad.zero]
        # print("Some values are zero in da")

    }
    return(da.distance.values)

}

build.background.model.and.score.calculation<-function(target.da.distance.values,
                                                       target.sa.distance.values,
                                                       model.da.distance.values,
                                                       model.sa.distance.values,
                                                       model.file.name) {

    v1<-matrix(target.da.distance.values,ncol=2)[,1]
    v2<-matrix(target.da.distance.values,ncol=2)[,2]
    ############# da parametric modelling2
    fit.weibull.da <- fitdist(model.da.distance.values, "weibull")
    fit.norm.da <- fitdist(model.da.distance.values, "norm")
    fit.lnorm.da <- fitdist(model.da.distance.values, "lnorm")
    fit.gamma.da <- fitdist(model.da.distance.values, "gamma")
    ############# da non-parametric modelling
    # fit.kde.da <- kdensity(model.da.distance.values, start = "normal", kernel = "gaussian")
    # fit.kde.da <- kdensity(model.da.distance.values)

    aic.values<-c(fit.weibull.da$aic, fit.norm.da$aic, fit.lnorm.da$aic, fit.gamma.da$aic)
    model.names<-c("weibull", "norm", "lnorm", "gamma")
    model.names.aic<-as.matrix(cbind(model.names, aic.values))
    best.da.model<-model.names.aic[order(as.numeric(model.names.aic[,2])),][1,1]
    # print(model.names.aic[order(as.numeric(model.names.aic[,2])),])
    matrix.da.model.names.aic<-model.names.aic[order(as.numeric(model.names.aic[,2])),]
    # print(as.matrix(cbind("kdensity", AIC(fit.kde.da))))
                                        # 2.225074e-308

    if (best.da.model == "weibull") {
        fit.weibull.da.shape<-fit.weibull.da$estimate[1]
        fit.weibull.da.rate<-fit.weibull.da$estimate[2]
        # dx.da<-dweibull(sequence.values,fit.weibull.da.shape,fit.weibull.da.rate)
    
        typicality.da.probs.v1<-dweibull(v1,fit.weibull.da.shape,fit.weibull.da.rate)
        typicality.da.probs.v2<-dweibull(v2,fit.weibull.da.shape,fit.weibull.da.rate)
        typicality.sa.probs<-dweibull(target.sa.distance.values,fit.weibull.da.shape,fit.weibull.da.rate)

    }
    if (best.da.model == "norm") {
        fit.norm.da.shape<-fit.norm.da$estimate[1]
        fit.norm.da.rate<-fit.norm.da$estimate[2]
        # dx.da<-dnorm(sequence.values,fit.norm.da.shape,fit.norm.da.rate)

        typicality.da.probs.v1<-dnorm(v1,fit.norm.da.shape,fit.norm.da.rate)
        typicality.da.probs.v2<-dnorm(v2,fit.norm.da.shape,fit.norm.da.rate)
        typicality.sa.probs<-dnorm(target.sa.distance.values,fit.norm.da.shape,fit.norm.da.rate)

    }
    if (best.da.model == "lnorm") {
        fit.lnorm.da.shape<-fit.lnorm.da$estimate[1]
        fit.lnorm.da.rate<-fit.lnorm.da$estimate[2]
        # dx.da<-dlnorm(sequence.values,fit.lnorm.da.shape,fit.lnorm.da.rate)

        typicality.da.probs.v1<-dlnorm(v1,fit.lnorm.da.shape,fit.lnorm.da.rate)
        typicality.da.probs.v2<-dlnorm(v2,fit.lnorm.da.shape,fit.lnorm.da.rate)
        typicality.sa.probs<-dlnorm(target.sa.distance.values,fit.lnorm.da.shape,fit.lnorm.da.rate)

    }
    if (best.da.model == "gamma") {
        fit.gamma.da.shape<-fit.gamma.da$estimate[1]
        fit.gamma.da.rate<-fit.gamma.da$estimate[2]
        # dx.da<-dgamma(sequence.values,fit.gamma.da.shape,fit.gamma.da.rate)

        typicality.da.probs.v1<-dgamma(v1,fit.gamma.da.shape,fit.gamma.da.rate)
        typicality.da.probs.v2<-dgamma(v2,fit.gamma.da.shape,fit.gamma.da.rate)
        typicality.sa.probs<-dgamma(target.sa.distance.values,fit.gamma.da.shape,fit.gamma.da.rate)

    }

    # print("Finished da modelling")

    ############# sa parametric modelling
    fit.weibull.sa <- fitdist(model.sa.distance.values, "weibull")
    fit.norm.sa <- fitdist(model.sa.distance.values, "norm")
    fit.lnorm.sa <- fitdist(model.sa.distance.values, "lnorm")
    fit.gamma.sa <- fitdist(model.sa.distance.values, "gamma")
    ############# sa non-parametric modelling
    # fit.kde.sa <- kdensity(model.sa.distance.values, start = "normal", kernel = "gaussian")
    # fit.kde.sa <- kdensity(model.sa.distance.values)

    aic.values<-c(fit.weibull.sa$aic, fit.norm.sa$aic, fit.lnorm.sa$aic, fit.gamma.sa$aic)
    model.names<-c("weibull", "norm", "lnorm", "gamma")
    model.names.aic<-as.matrix(cbind(model.names, aic.values))
    best.sa.model<-model.names.aic[order(as.numeric(model.names.aic[,2])),][1,1]

    # print(model.names.aic[order(as.numeric(model.names.aic[,2])),])
    matrix.sa.model.names.aic<-model.names.aic[order(as.numeric(model.names.aic[,2])),]
    # print(as.matrix(cbind("kdensity", AIC(fit.kde.sa))))

    if (best.sa.model == "weibull") {
        fit.weibull.sa.shape<-fit.weibull.sa$estimate[1]
        fit.weibull.sa.rate<-fit.weibull.sa$estimate[2]
        # dx.sa<-dweibull(sequence.values,fit.weibull.sa.shape,fit.weibull.sa.rate)

        similarity.da.probs.v1<-dweibull(v1,fit.weibull.sa.shape,fit.weibull.sa.rate)
        similarity.da.probs.v2<-dweibull(v2,fit.weibull.sa.shape,fit.weibull.sa.rate)
        similarity.sa.probs<-dweibull(target.sa.distance.values,fit.weibull.sa.shape,fit.weibull.sa.rate)

    }
    if (best.sa.model == "norm") {
        fit.norm.sa.shape<-fit.norm.sa$estimate[1]
        fit.norm.sa.rate<-fit.norm.sa$estimate[2]
        # dx.sa<-dnorm(sequence.values,fit.norm.sa.shape,fit.norm.sa.rate)

        similarity.da.probs.v1<-dnorm(v1,fit.norm.sa.shape,fit.norm.sa.rate)
        similarity.da.probs.v2<-dnorm(v2,fit.norm.sa.shape,fit.norm.sa.rate)
        similarity.sa.probs<-dnorm(target.sa.distance.values,fit.norm.sa.shape,fit.norm.sa.rate)

    }
    if (best.sa.model == "lnorm") {
        fit.lnorm.sa.shape<-fit.lnorm.sa$estimate[1]
        fit.lnorm.sa.rate<-fit.lnorm.sa$estimate[2]
        # dx.sa<-dlnorm(sequence.values,fit.lnorm.sa.shape,fit.lnorm.sa.rate)

        similarity.da.probs.v1<-dlnorm(v1,fit.lnorm.sa.shape,fit.lnorm.sa.rate)
        similarity.da.probs.v2<-dlnorm(v2,fit.lnorm.sa.shape,fit.lnorm.sa.rate)
        similarity.sa.probs<-dlnorm(target.sa.distance.values,fit.lnorm.sa.shape,fit.lnorm.sa.rate)

    }
    if (best.sa.model == "gamma") {
        fit.gamma.sa.shape<-fit.gamma.sa$estimate[1]
        fit.gamma.sa.rate<-fit.gamma.sa$estimate[2]
        # dx.sa<-dgamma(sequence.values,fit.gamma.sa.shape,fit.gamma.sa.rate)

        similarity.da.probs.v1<-dgamma(v1,fit.gamma.sa.shape,fit.gamma.sa.rate)
        similarity.da.probs.v2<-dgamma(v2,fit.gamma.sa.shape,fit.gamma.sa.rate)
        similarity.sa.probs<-dgamma(target.sa.distance.values,fit.gamma.sa.shape,fit.gamma.sa.rate)

    }

    # print("Finished sa modelling")

    write.table(rbind(c("sa.models", "sa.aic", "da.model", "da.aic"),cbind(matrix.sa.model.names.aic,matrix.da.model.names.aic)),
                file=model.file.name, sep=" ", quote=FALSE, col.names=FALSE, row.names=FALSE)
    
    # print(paste("sa max", max(target.sa.distance.values), sep=" "))
    # print(paste("sa min", min(target.sa.distance.values), sep=" "))
    # print(paste("da max", max(target.da.distance.values), sep=" "))
    # print(paste("da min", min(target.da.distance.values), sep=" "))

    da.scores.v1<-log10(similarity.da.probs.v1 / typicality.da.probs.v1)
    da.scores.v2<-log10(similarity.da.probs.v2 / typicality.da.probs.v2)

    da.scores<-c(da.scores.v1,da.scores.v2)
    sa.scores<-log10(similarity.sa.probs / typicality.sa.probs)

    return(list(sa.scores,da.scores))
    
}

accuracy.calculation<-function(sa.lr.file, da.lr.file, accuracy.file.name) {
    sa.lrs<-read.table(sa.lr.file,header=FALSE)
    da.lrs<-read.table(da.lr.file,header=FALSE)

    sa.accuracy<-(length(which(sa.lrs > 0))/nrow(sa.lrs))
    da.accuracy<-(length(which(da.lrs < 0))/nrow(da.lrs))
    average.accuracy<-mean(c(sa.accuracy, da.accuracy))

    # print(sa.accuracy)
    # print(da.accuracy)
    # print(average.accuracy)

    write.table(rbind(sa.accuracy,da.accuracy,average.accuracy),
                file=accuracy.file.name, sep=" ", quote=FALSE, col.names=FALSE, row.names=TRUE)

    return(rbind(sa.accuracy,
                 da.accuracy,
                 average.accuracy))

}

data.manupulation<-function(original.data,n.col) {

    if (ncol(original.data) == (n.col + 1)) {
        selected.data<-original.data[,-1:-4]
        row.sum.values<-rowSums(selected.data)
        selected.relative.frequencies<-selected.data/row.sum.values
        out.x<-selected.relative.frequencies

    } else {
        all.data<-original.data[,-1:-4]
        row.sum.values.all.data<-rowSums(all.data)
        all.relative.frequencies<-all.data/row.sum.values.all.data
        out.x<-all.relative.frequencies[,c(1:(n.col-4),ncol(all.data))]

        # all.relative.frequencies.selected<-all.relative.frequencies[,1:(n.col-4)]
        # all.relative.frequencies.unselected<-rowSums(all.relative.frequencies[,(n.col-3):ncol(all.data)])

        # out.x<-cbind(all.relative.frequencies.selected,all.relative.frequencies.unselected)
        
        # selected.data<-original.data[,5:n.col]
        # row.sum.values<-rowSums(selected.data)
        # print(row.sum.values[1:2])
        # unselected.data<-original.data[,(n.col+1):ncol(original.data)]
        # print(length(unselected.data))
        # unselected.row.sum.values<-rowSums(unselected.data)
        # selected.relative.frequencies<-selected.data/row.sum.values
        # unselected.relative.frequencies<-unselected.row.sum.values/row.sum.values
        # out.x<-cbind(selected.relative.frequencies,unselected.relative.frequencies)

    }
    return(out.x)

}

data.manupulation.smoothing.deep<-function(original.data,n.col) {
    # numerical.data<-(original.data[,5:ncol(original.data)])
                                        # row.sum.values<-rowSums(numerical.data)
    if (ncol(original.data) == (n.col + 1)) {
        # selected.data<-(original.data[,-1:-4] + 1)
        selected.data<-(original.data + 1)
        out.x<-selected.data
        
    } else {
        # selected.data<-(original.data[,5:n.col] + 1)
        selected.data<-(original.data[,1:n.col] + 1)
        unselected.data<-(original.data[,(n.col+1):ncol(original.data)] + 1)
        unselected.row.sum.values<-rowSums(unselected.data)
        out.x<-cbind(selected.data,unselected.row.sum.values)

    }
    # selected.relative.frequencies<-selected.data/row.sum.values
    # unselected.relative.frequencies<-unselected.row.sum.values/row.sum.values

    return(out.x)

}

data.manupulation.smoothing<-function(original.data,n.col) {
    # numerical.data<-(original.data[,5:ncol(original.data)])
                                        # row.sum.values<-rowSums(numerical.data)
    if (ncol(original.data) == (n.col + 1)) {
        selected.data<-(original.data[,-1:-4] + 1)
        out.x<-selected.data
        
    } else {
        selected.data<-(original.data[,5:n.col] + 1)
        unselected.data<-(original.data[,(n.col+1):ncol(original.data)] + 1)
        unselected.row.sum.values<-rowSums(unselected.data)
        out.x<-cbind(selected.data,unselected.row.sum.values)

    }
    # selected.relative.frequencies<-selected.data/row.sum.values
    # unselected.relative.frequencies<-unselected.row.sum.values/row.sum.values

    return(out.x)

}

build.calibration.model.and.lr.calculation<-function(target.da.distance.values,
                                                     target.sa.distance.values,
                                                     model.da.distance.values,
                                                     model.sa.distance.values,
                                                     cllr.out.file) {

    # v1<-matrix(target.da.distance.values,ncol=2)[,1]
    # v2<-matrix(target.da.distance.values,ncol=2)[,2]

    w<-train.llr.fusion(log(matrix(model.sa.distance.values, nrow=1)),
                        log(matrix(model.da.distance.values, nrow=1)))

    logetss<-lin.fusion(w, log(matrix(target.sa.distance.values, nrow=1)))
    logetds<-lin.fusion(w, log(matrix(target.da.distance.values, nrow=1)))
    log10tss<-log10(exp(logetss))
    log10tds<-log10(exp(logetds))

    da.false.values<-rep(FALSE, length(logetds))
    sa.true.values<-rep(TRUE, length(logetss))
    sa.da.scores<-c(logetss,logetds)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)

    # calib.cllr.value<-summary(roc.out)$Cllr
    calib.cllr.value<-summary.roc(roc.out)$Cllr
    # calib.cllr.min.value<-summary(roc.out)$Cllr.min
    calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    calib.cllr.cal.value<-calib.cllr.value - calib.cllr.min.value
    # calib.eer.value<-summary(roc.out)$eer / 100
    calib.eer.value<-summary.roc(roc.out)$eer / 100

    calib.cllr.min.cal.values <- c(calib.cllr.value,
                                   calib.cllr.min.value,
                                   calib.cllr.cal.value,
                                   calib.eer.value

                                   )
    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal", "eer"),
                                            c("before_calib", calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
    )

    write.table(title.calib.cllr.min.cal.values,file=cllr.out.file, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(list(log10tss,log10tds,calib.cllr.min.cal.values))
    
}


