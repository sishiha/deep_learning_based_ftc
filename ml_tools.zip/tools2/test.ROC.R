library(ROC)

calc.roc.cllr.eer<-function(sa.scores,da.scores) {
    #### da scores
    da.false.values<-rep(FALSE, length(da.scores))
    #### sa scores
    sa.true.values<-rep(TRUE, length(sa.scores))
    log10.sa.da.scores<-c(sa.scores,da.scores)
    ### converting to natural log values
    sa.da.scores<-log(10^log10.sa.da.scores)

    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))
    roc.out<-roc(sa.da.data)
    cllr<-summary(roc.out)$Cllr
    cllr.min<-summary(roc.out)$Cllr.min
    cllr.cal<-cllr - cllr.min
    eer<-summary(roc.out)$eer / 100

    all<-c(cllr,cllr.min,cllr.cal,eer)
    
    return(all)

}


