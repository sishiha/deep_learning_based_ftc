# alpha: a parameter vector for a dirichlet distribution
# x = a vector of counts: suspect
# y = a vector of counts: offender

## linear Beta function
B<-function(alpha) {
    numerator<-prod(gamma(alpha))
    denominator<-gamma(sum(alpha))
    out<-numerator/denominator
    return(out)
}

## natural log Beta function
logB<-function(alpha) {
    numerator<-sum(lgamma(alpha))
    denominator<-lgamma(sum(alpha))
    log.out<-numerator - denominator
    return(log.out)
}

## outut is linear LR
LR<-function(alpha,x,y) {
    first.fraction<-B(alpha) / B(alpha + y)
    second.fraction<-B(alpha + x + y) / B(alpha + x)
    LR.out<-first.fraction*second.fraction
    return(LR.out)
}

## outut is natural log LR
log10LR.mnom.two.level<-function(x,y,alpha) {
    first.fraction<-logB(alpha) - logB(alpha + y)
    second.fraction<-logB(alpha + x + y) - logB(alpha + x)
    logLR<-first.fraction + second.fraction
    log10LR<-logLR/log(10)
    return(log10LR)
}

log10LR.mnom.one.level<-function(x.counts,y.counts,typicality.probs) {
    x.probs<-x.counts/sum(x.counts) # change x.counts to x.probs
    top<-dmultinom(x=y.counts,prob=x.probs,log=TRUE)
    bottom<-dmultinom(x=y.counts, prob=typicality.probs,log=TRUE)
    logLR<-top - bottom
    log10LR<-logLR/log(10)
    return(log10LR)
    
}

modified.log10LR.mnom.two.level<-function(vec, alpha) {
    llength<-length(vec)
    mid <- length(vec) / 2

    first.half<-vec[1:mid]
    second.half<-vec[(mid+1):llength]

    score<-log10LR.mnom.two.level(first.half, second.half, alpha)
    return(score)

}
