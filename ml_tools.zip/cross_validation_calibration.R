
library("stringr")

cross.validate.calibrate.roc.eer.ver2<-function(tf,         # a file containing scores
                                                lrfilename, # a file to which the resultant LRs are saved
                                                filename) { # a file for the Cllr-related values

    file.sources1 = list.files("./focal_r/cllr",full.names=TRUE, pattern="*.[Rr]$")
    file.sources2 = list.files("./focal_r/fusion",full.names=TRUE, pattern="*.[Rr]$")
    file.sources3 = list.files("./focal_r/utils",full.names=TRUE, pattern="*.[Rr]$")
    sapply(file.sources1,source,.GlobalEnv)
    sapply(file.sources2,source,.GlobalEnv)
    sapply(file.sources3,source,.GlobalEnv)

    test.readin<-read.table(tf, header=TRUE)
    
    tss1<-test.readin[which(test.readin[,5] == 1),1]
    logetss <- rbind(tss1*log(10))

    tss1.author.pairs<-test.readin[which(test.readin[,5] == 1),2]
    tss1.product.pairs<-test.readin[which(test.readin[,5] == 1),3]
    tss1.fixed.product.pairs<-test.readin[which(test.readin[,5] == 1),4]
    tss1.so.do<-test.readin[which(test.readin[,5] == 1),5]

    tss<-data.frame(x=as.vector(logetss),
                    y=as.character(tss1.author.pairs),
                    z=as.character(tss1.product.pairs),
                    i=as.character(tss1.fixed.product.pairs),
                    j=as.vector(tss1.so.do))

    tds1<-test.readin[which(test.readin[,5] == 0),1]
    logetds <- rbind(tds1*log(10))

    tds1.author.pairs<-test.readin[which(test.readin[,5] == 0),2]
    tds1.product.pairs<-test.readin[which(test.readin[,5] == 0),3]
    tds1.fixed.product.pairs<-test.readin[which(test.readin[,5] == 0),4]
    tds1.so.do<-test.readin[which(test.readin[,5] == 0),5]

    tds<-data.frame(x=as.vector(logetds),
                    y=as.character(tds1.author.pairs),
                    z=as.character(tds1.product.pairs),
                    i=as.character(tds1.fixed.product.pairs),
                    j=as.vector(tds1.so.do))

    t<-rbind(tss,tds)

    t1.author.pairs<-c(as.vector(tss1.author.pairs), as.vector(tds1.author.pairs))
    t1.product.pairs<-c(as.vector(tss1.product.pairs), as.vector(tds1.product.pairs))
    t1.fixed.product.pairs<-c(as.vector(tss1.fixed.product.pairs), as.vector(tds1.fixed.product.pairs))
    t1.so.do<-c(as.vector(tss1.so.do), as.vector(tds1.so.do))


    resultant.lrs <- NULL
    for (i in 1:nrow(t)) {
        target.score<-t[i,1]
        target.authors<-as.character(t[i,2])
        target1<-unlist(strsplit(target.authors, split="--"))[1]
        target2<-unlist(strsplit(target.authors, split="--"))[2]

        if (target1 == target2) {
            data1 <- t[str_detect(t[,2], target1, negate = TRUE), ]  # Extract matching rows with str_detect

        } else {
            target12<-paste(c(target1, target2), collapse="|")
            data1 <- t[str_detect(t[,2], target12, negate = TRUE), ]  # Extract matching rows with str_detect

        }


        all.so.scores<-rbind(data1[which(data1[,5] == 1), 1])
        all.do.scores<-rbind(data1[which(data1[,5] == 0), 1])

        w <- train.llr.fusion(all.so.scores, all.do.scores)
        target.raw.lr <- lin.fusion(w, as.matrix(target.score))

        target.log10.lr<-log10(exp(target.raw.lr))

        resultant.lrs<-c(resultant.lrs, target.log10.lr)
        
    }

    lrs.out<-data.frame(lrs=resultant.lrs,
                        authorpairs=t1.author.pairs,
                        productpairs = t1.product.pairs,
                        fixedproductpairs = t1.fixed.product.pairs,
                        sodo=t1.so.do)

    write.table(lrs.out, lrfilename, sep=" ", row.names=FALSE, quote=FALSE)

### non calib cllr, cllrmin, cllrcal values
    da.false.values<-rep(FALSE, length(logetds))
    sa.true.values<-rep(TRUE, length(logetss))
    sa.da.scores<-c(logetss,logetds)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)
    non.calib.cllr.value<-summary.roc(roc.out)$Cllr
    non.calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    non.calib.cllr.cal.value<-non.calib.cllr.value - non.calib.cllr.min.value
    non.calib.eer.value<-summary.roc(roc.out)$eer / 100
    
    non.calib.cllr.min.cal.values <- c(non.calib.cllr.value,
                                       non.calib.cllr.min.value,
                                       non.calib.cllr.cal.value,
                                       non.calib.eer.value)
    
    print(non.calib.cllr.min.cal.values)

### calib cllr, cllrmin, cllrcal values

    targetf<-lrs.out[which(lrs.out[,5] == 1),1] * log(10)
    nontargetf<-lrs.out[which(lrs.out[,5] == 0),1] * log(10)
    
    da.false.values<-rep(FALSE, length(nontargetf))
    sa.true.values<-rep(TRUE, length(targetf))
    sa.da.scores<-c(targetf,nontargetf)
    sa.da.data<-data.frame(score=sa.da.scores,target=as.logical(c(sa.true.values,da.false.values)))

    roc.out<-roc(sa.da.data)
    calib.cllr.value<-summary.roc(roc.out)$Cllr
    calib.cllr.min.value<-summary.roc(roc.out)$Cllr.min
    calib.cllr.cal.value<-calib.cllr.value - calib.cllr.min.value
    calib.eer.value<-summary.roc(roc.out)$eer / 100

    calib.cllr.min.cal.values <- c(calib.cllr.value,
                                   calib.cllr.min.value,
                                   calib.cllr.cal.value,
                                   calib.eer.value
                                   )
    
    title.calib.cllr.min.cal.values<-(rbind(c("before/after_calib", "cllr","cllrmin","cllrcal", "eer"),
                                            c("before_calib", non.calib.cllr.min.cal.values),
                                            c("after_calib", calib.cllr.min.cal.values))
    )

    write.table(title.calib.cllr.min.cal.values,file=filename, sep=" ", quote=FALSE,
                row.names = FALSE, col.names = FALSE)

    return(rbind(non.calib.cllr.min.cal.values, calib.cllr.min.cal.values))

    # rm(list=ls(all=TRUE))

}

test.score.file<-"../ml_experiment_outcome/score_dump/test_scores_iter_2_2gram_ref_123_test_4_calib_5_fnumber_100.txt"
test.lr.file<-"../ml_experiment_outcome/lr_dump/testxxx.txt"
cllr.file<-"../ml_experiment_outcome/metrics/testxxx.txt"

x<-cross.validate.calibrate.roc.eer.ver2(test.score.file, test.lr.file, cllr.file)
print(x)
